/* Elabore uma sub-rotina que receba como parâmetro um valor N (inteiro e maior ou igual a 1) e determi-
ne o valor da sequência S, descrita a seguir: S = 1 + 1/2 + 1/3... */


//Nao entendi o objetivo da questao!!!
//perdao.